package fr.synchroneyes.mineral.Exception;

public class MaterialNotInRangeException extends Exception {
    public MaterialNotInRangeException() {
        super();
    }
}
