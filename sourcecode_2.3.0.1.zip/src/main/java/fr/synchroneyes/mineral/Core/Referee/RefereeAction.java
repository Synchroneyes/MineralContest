package fr.synchroneyes.mineral.Core.Referee;

public enum RefereeAction {


}
