package fr.synchroneyes.mineral.Core.Coffre.Event;

import org.bukkit.event.Listener;

public class ChestOpenEvent implements Listener {






}
