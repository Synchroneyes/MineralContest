package fr.synchroneyes.mineral.Scoreboard;

import org.bukkit.entity.Player;


public interface BoardPage {
    void update(Player p);
}